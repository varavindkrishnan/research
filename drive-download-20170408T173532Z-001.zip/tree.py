operators = ("EXTENDS", "MULS", "CCAST", "ASSIGN", "ADD", "SUB", "AND", "OR", "NEGATE", "ASSIGNDLY", "SHIFTL", "SHIFTR",
    "ASSIGNW", "EQ", "XOR", "NEQ", "LT", "LTE", "GT", "GTE", "COND", "NOT", "ASSIGNPRE", "ASSIGNPOST", "ARRAYSEL")
terminals = ("CONST", "VARREF")
assigns = ("ASSIGN", "ASSIGNDLY", "ASSIGNW", "ASSIGNPRE", "ASSIGNPOST")
single_operand = ("CCAST", "NEGATE", "NOT", "EXTENDS")
cover = "COVERINC"


class assign_tree:
    " assignment trees inside each node"
    def __init__(self, key=None, children = None):
        self.key = key
        self.children = []
        if children is not None:
            for child in children:
                assert isinstance(child, assign_tree)
                self.children.append(child)


class control_flow_tree:
    " models if then else control flow "
    def __init__(self, predicate = None, key=None, children = None, cov_id = None):
        assert isinstance(key, assign_tree)
        self.key = key
        assert isinstance(predicate, assign_tree)
        self.predicate = predicate
        self.children = []
        if children is not None:
            for child in children:
                assert isinstance(child, control_flow_tree)
                self.children.append(child)

        if id is not None:
            assert(id, int)
            self.id = id

        else:
            self.id = None


