from parse_tree import get_second_level, get_third_level, get_assign_tree, indent_level, get_last_level
from scan_file import get_operator
from tree import control_flow_tree


def get_predicate(j, lines):
    return get_assign_tree(j, lines)


def get_then(j, lines, predicate):
    assert(indent_level(lines[j])[0] == 2)
    
    # get assigns from here
    # if u see another predicate call get if then nodes
    # initialize node using above predicate


def get_otherwise(j, lines, predicate):
    assert (indent_level(lines[j])[0] == 3)
    # get assigns from here
    # if u see another predicate call get if then nodes
    # initialize node using above predicate


def indent(line):
    split = line.split(" ")
    temp = []
    for element in split:
        if not (element == ""):
            temp.append(element)

    temp = temp[0]
    return temp


def get_if_then_nodes(i, lines):
    j = get_second_level(i + 1, lines)
    q = get_last_level(i, lines)
    level = indent(lines[q - 1])
    if level[-2] == 2:
        predicate = get_predicate(i + 1, lines)
        then = get_then(j, lines, predicate)
        return [then]

    else:
        k = get_third_level(i + 1, lines)
        predicate = get_predicate(i + 1, lines)
        then = get_then(j, lines, predicate)
        otherwise = get_otherwise(k, lines, predicate)
        return [then, otherwise]



ast = open("Vtop_990_final.tree", 'r')
lines = ast.readlines()
i = 0
node_a = []

while i < len(lines):
    operator = get_operator(lines[i])

    if operator == "IF":
        temp = get_if_then_nodes(i, lines)
        i = get_last_level(i, lines)
        if len(temp) == 1:
            node_a.append(temp)

        elif len(temp) == 2:
            node_a.append(temp[0])
            node_a.append(temp[1])

        else:
            assert False

    else:
        i += 1





