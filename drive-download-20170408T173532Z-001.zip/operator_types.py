operators = ("EXTENDS", "MULS", "CCAST", "ASSIGN", "ADD", "SUB", "AND", "OR", "NEGATE", "ASSIGNDLY", "SHIFTL", "SHIFTR",
    "ASSIGNW", "EQ", "XOR", "NEQ", "LT", "LTE", "GT", "GTE", "COND", "NOT", "ASSIGNPRE", "ASSIGNPOST", "ARRAYSEL")

terminals = ("CONST", "VARREF")

assigns = ("ASSIGN", "ASSIGNDLY", "ASSIGNW", "ASSIGNPRE", "ASSIGNPOST")

single_operand = ("CCAST", "NEGATE", "NOT", "EXTENDS")

two_operand = ("MULS", "ASSIGN", "ADD", "SUB", "AND", "OR", "ASSIGNDLY", "SHIFTL", "SHIFTR",
    "ASSIGNW", "EQ", "XOR", "NEQ", "LT", "LTE", "GT", "GTE", "ASSIGNPRE", "ASSIGNPOST", "ARRAYSEL")

three_operand = ("COND")

cover = "COVERINC"